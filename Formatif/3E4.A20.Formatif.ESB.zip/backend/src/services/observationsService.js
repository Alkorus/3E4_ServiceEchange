import dayjs from 'dayjs';
import Observations from '../models/observation.js';

class ObservationsService {
    retrieveAll(options) {
        let retrieveQuery = Observations.find();
        let countQuery = Observations.countDocuments();

        if (options.humidity) {
            //TODO[2b] : Ajouter les paramètres des méthodes find (L11 et L12) pour ajouter le critère  --> humidity doit > que l'option fournie
            retrieveQuery = Observations.find(); 
            countQuery = Observations.countDocuments(); 
        }

        retrieveQuery.limit().skip().sort(); //TODO:[2a] Ajouter les paramètre au trois fonction sur la requête moongoose

        return Promise.all([retrieveQuery, countQuery]);
    }

    transform(observation) {

        //TODO[2c]: href

        //TODO[2c]: href de la planet
       
        //TODO[2c]: Format de la date YYYY-MM-DD HH:mm:ss

        //TODO[2c]: Supprimer id

        return observation;
    }
}

export default new ObservationsService();
