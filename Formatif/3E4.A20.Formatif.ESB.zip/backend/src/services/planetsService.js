import Planets from '../models/planet.js';

import observationsService from './observationsService.js';

class PlanetsService {

    retrieveOne(idPlanet, options) {
    
        //TODO[1c]: Si les observations sont demandées ajuster la requête en conséquence
        return Planets.findById(idPlanet);
    }

    transform(planet, options = {}) {

        planet.href = `${process.env.BASE_URL}/planets/${planet._id}`;

        if(options.isObservationsEmbed) {
            planet.observations.map(o => {
                o = observationsService.transform(o);
                return o;
            });
        }

        delete planet._id;
        delete planet.id;

        return planet;

    }
}

export default new PlanetsService();