const SERVICE_URL = 'http://es3e4-a20.us-3.evennode.com/planets/';
const SERVICE_URL_OBSERVATIONS = 'http://es3e4-a20.us-3.evennode.com/planets/5f1ef4071d2fd12580bf11c7?embed=observations';

const HttpCodes = {
    SUCCESS: 200,
    NOT_FOUND: 404,
};

$(document).ready(() => {
    getPlanet();
    $('#btnLoadObservations').click(loadObservations);
});

async function getPlanet() {
    try {
        const response = await axios.get(SERVICE_URL);
        if (response.status === HttpCodes.SUCCESS) {
            const planets = response.data;
            planets.forEach((p) => {
                $('#cboPlanet').append(`<option value='${p.href}?embed=observations'>${p.name}</option>`);
            });
        }
    } catch (err) {
        console.log(err);
    }
}

async function loadObservations() {

    //TODO[3a]
    $('#observations tr:gt(0)').remove(); //Cette ligne efface toutes les lignes du tableau exluant l'en-tête, PAS TOUCHE

    try {
        //TODO: Récupérer la valeur de la liste déroulante, si vous n'êtes pas en mesure utiliser la constante SERVICE_URL_OBSERVATIONS
        
        //TODO Faire le requête AJAX avec axios et la valeur de liste déroulante ou la constante SERVICE_URL_OBSERVATIONS
        //const response =
        
        if (response.status === HttpCodes.SUCCESS) {
            //TODO: Utiliser la fonction generateObservationHtml pour afficher chacun des observations dans le tableau #observations
        }
    } catch (err) {
        console.log(err);
    }
}

function generateObservationHtml(observation) {
    let observationHtml = '<tr>';
    observationHtml += `<td class="align-middle">${observation.location.station}</td>`;
    observationHtml += `<td class="align-middle">${observation.observationDate}</td>`;
    observationHtml += `<td class="align-middle">`;
    observationHtml += `<img class="iconMonster" src="" /><br />`; //TODO:[3b] Remplacer la propriété src de l'image par celle l'asset du scientific de l'observation
    observationHtml += `Nom du scientific` //TODO:[3b]  Afficher ici le nom du scientific de l'observation
    observationHtml += '</td>';
    observationHtml += `<td class="align-middle">${observation.temperature}</td>`;
    observationHtml += `<td class="align-middle">${observation.feelslike}</td>`;
    observationHtml += `<td class="align-middle">${observation.humidity}</td>`;
    observationHtml += `<td class="align-middle">${observation.pressure}</td>`;
    observationHtml += `<td class="align-middle">${observation.uvIndex}</td>`;
    observationHtml += '</tr>';

    return observationHtml;
}
