
class ExplorationsService {
    
}