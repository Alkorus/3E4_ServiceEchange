import Teams from '../models/team.js';
import gamesService from './gamesService.js';

class TeamsService {
    
    retrieveOne(options) {
        //ATTENTION: Vous ne pouvez pas modifier cette fonction
        return Teams.findById(options.idTeam);
    }

    retrieveAll(options) {
        let query = Teams.find();
        //TODO[1e]: Ajouter l'option de retrouver l'équipe de joueur avec nom fourni
        
        return query;
    }

    transform(team) {
        
        delete team._id;
        
        //TODO[1d]: Ajouter le href à l'équipe
        
        //TODO[1d]: Ajouter la propriété rating à l'équipe qui correspond à la moyenne des ratings des joueurs de l'équipe

        return team;
    }
}

export default new TeamsService();
