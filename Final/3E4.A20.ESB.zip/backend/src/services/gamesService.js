import Games from '../models/game.js';

class GamesService {

    retrieveOne(idGame) {
        let query = Games.findById(idGame).populate('home').populate('away');
        return query;
    }
    
    retrieveAll(options) {
        
        //TODO[2a] Prendre en considération les paramètres pour la pagination et le tri (ATTENTION: Il faut conserver les populate sur home et away)
        const retrieveQuery = Games.find().limit().skip().sort().populate('home').populate('away');
        //TODO[2a] Ajouter la requête pour compter le nombre de document
        
        //TODO[2a] Modifier la retour de la méthode
        return retrieveQuery;
    }
 
    transform(game) {
      
        game.href = `${process.env.BASE_URL}/games/${game._id}`;
        
        if(game.home.planet) {
            game.home = game.home.planet;
        }
        if(game.away.planet) {
            game.away = game.away.planet;
        }
        
        //TODO[2c] Résultat de la partie

        delete game._id;

        return game;
    }
}

export default new GamesService();